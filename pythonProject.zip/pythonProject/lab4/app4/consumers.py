from channels.generic.websocket import JsonWebsocketConsumer

class CommentNotificationConsumer(JsonWebsocketConsumer):
    def connect(self):
        self.accept()

    def notify_new_comment(self, event):
        self.send_json(event)