from rest_framework.test import APITestCase
from rest_framework import status
from django.contrib.auth.models import User
from app4.models import Post
from rest_framework_simplejwt.tokens import RefreshToken


class PostTests(APITestCase):

    def setUp(self):
        self.user = User.objects.create_user(username='user', password='password')

        refresh = RefreshToken.for_user(self.user)
        self.token = str(refresh.access_token)

    def test_create_post(self):
        headers = {'Authorization': f'Bearer {self.token}'}

        data = {'title': 'Test Post', 'content': 'This is a test post.'}
        response = self.client.post('/api/posts/', data, format='json', **headers)

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_get_posts(self):
        headers = {'Authorization': f'Bearer {self.token}'}
        post = Post.objects.create(title='Test Post', content='This is a test post.', author=self.user)
        response = self.client.get(f'/api/posts/{post.id}/', **headers)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['title'], 'Test Post')

